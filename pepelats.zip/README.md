# Pepelats - Audio looper and drum machine on Raspberry Pi
 
### Hardware required
Raspberry Pi versions: Zero-2W, 3B+, 4, 5

### [Web documentation](https://slmnv5.github.io/pepelats/docs/index.html)
